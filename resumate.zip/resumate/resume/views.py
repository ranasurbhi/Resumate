from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.decorators import login_required
from .forms import ResumeForm, AchievementForm, ExperienceForm, EducationForm, ProjectForm, SkillForm
from .models import Resume, UserProfile

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('resume_view')
    else:
        form = AuthenticationForm()

    return render(request, 'resume/login.html', {'form': form})

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'resume/register.html', {'form': form})

@login_required
def resume_view(request):
    try:
        resume = Resume.objects.get(user_profile__user=request.user)
    except Resume.DoesNotExist:
        resume = None

    if request.method == 'POST':
        form = ResumeForm(request.POST, request.FILES, instance=resume)
        if form.is_valid():
            resume = form.save(commit=False)
            resume.user_profile = UserProfile.objects.get(user=request.user)
            resume.save()
            return redirect('resume_view')  # Redirect to a success page or the same form

    else:
        form = ResumeForm(instance=resume) if resume else ResumeForm()

    return render(request, 'resume/resume.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('index')

from django.shortcuts import render

def index_view(request):
    return render(request, 'resume/index.html')  